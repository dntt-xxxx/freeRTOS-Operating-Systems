#include "cfgLed.h"

 const Led_conf_IO Led_CfgParam =
{
	/*Button GPIO*/
	GPIOA,
	GPIO_PIN_9,
	/*Led GPIO*/
	GPIOB,
	GPIO_PIN_6
};
